
#### 1. Get the latest version
$ git clone https://github.com/phucleit/omcloud
$ cd omcloud
```

#### 2. Run `npm install`

#### 3. Run `npm start`

Runs the app in the development mode http://localhost:4000.

# Sửa lỗi package (không cần thiết)
"start": "set PORT=4000 && react-scripts start",.
"start": "react-scripts --openssl-legacy-provider start",